<header class="navbar">
  <section class="navbar-section">
    <a href="<?php echo e(route('client_home')); ?>" class="navbar-brand mr-2">Drama</a>
  </section>
  <section class="navbar-section">
    <div class="input-group input-inline">
       <form action="<?php echo e(route('search')); ?>" method="POST">
        <?php echo csrf_field(); ?>
       <div class="input-group">
        <input class="form-input form-inline" type="text" name="name" required placeholder="Drama Name">
        <button class="btn btn-primary input-group-btn">Search</button>
       </div>
      </form>
    </div>
  </section>
</header>
<?php /**PATH C:\xampp\htdocs\resources\views/includes/client_header.blade.php ENDPATH**/ ?>