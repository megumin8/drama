<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.components.dramaCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="section columns">
   <?php if(isset($key_word)): ?>
   <div class="column">
    <h2>Search Result : <?php echo e($key_word); ?></h2>
    <a href="<?php echo e(route('client_home')); ?>">Go back</a>
   </div>
   <?php endif; ?>
    <div class="column col-12 flex_row">
        <?php $__currentLoopData = $dramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="drama" onclick="showcard('<?php echo e(json_encode($drama)); ?>')">
                <img src="<?php echo e($drama->cover); ?>" alt="" class="dramacover">
                <i class="dramaname"><?php echo e($drama->name); ?></i>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/home.blade.php ENDPATH**/ ?>